﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;

namespace Cotracts
{
   public class TaskRepository:ITaskRepository
    {
        static List<Job> jobs { get; set; }

        public TaskRepository()
        {
            jobs = new List<Job>();
        }
        public void AddTask(Job j)
        {
            jobs.Add(j);
        }

        public void DeleteTask(int id)
        {
            Job job = jobs.FirstOrDefault(j => j.ID == j.ID);
            jobs.Remove(job);
        }

        public void EditTask(Job j)
        {
            Job job = jobs.FirstOrDefault(j => j.ID == j.ID);
            if (job != null)
            {
                job.ID = j.ID;
                job.Name = j.Name;
                job.Description = j.Description;
                //job.Task_Owner = j.Task_Owner;
                //job.Creator_ID = j.Creator_ID;
                job.Priority = j.Priority;
                job.Status = j.Status;
                job.CreatedOn = j.CreatedOn;
                job.ModifiedOn = j.ModifiedOn;
                job.Completion_Date = j.Completion_Date;

            }
        }

        public List<Job> Get()
        {
            return jobs;
        }

        public Job GetTask(int id)
        {
            Job j = jobs.SingleOrDefault(j => j.ID == id);
            return j;
        }
    }
}
