﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;

namespace Cotracts
{
    public interface ITaskRepository
    {
        void AddTask(Job j);
        //void UpdateExam(Exam e);
        void DeleteTask(int id);
        List<Job> Get();
        Job GetTask(int id);
        void EditTask(Job j); 
    }
}
