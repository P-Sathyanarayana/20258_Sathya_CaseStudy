﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Entities;
using Cotracts;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CreateTask.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class JobsController : ControllerBase
    {
        public static List<Job> jobs = new List<Job>();
        //public static List<string> Courses = new List<string>
        ITaskRepository repo;
        public JobsController(ITaskRepository _repo)
        {
            repo = _repo;
        }
        // GET: api/<JobsController>
        [HttpGet]
        public List<Job> Get()
        {
            return repo.Get();
        }

        // GET api/<JobsController>/5
        [HttpGet("{id}")]
        public Job Get(int id)
        {
            return repo.Get().FirstOrDefault(e => e.ID == id);
        }

        // POST api/<JobsController>
        [HttpPost]
        public void Post([FromBody] Job task)
        {
            repo.AddTask(task);
        }

        // PUT api/<JobsController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] Job task)
        {
            repo.EditTask(task);
        }

        // DELETE api/<JobsController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            repo.DeleteTask(id);
        }
    }
}
