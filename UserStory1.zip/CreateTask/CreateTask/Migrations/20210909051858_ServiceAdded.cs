﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CreateTask.Migrations
{
    public partial class ServiceAdded : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
