﻿using System;
using System.Net.Http;

namespace ClientSide
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:64694/api/");
                //HTTP GET
                var responseTask = client.GetAsync("jobs");
                responseTask.Wait();
                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();
                    var courses = readTask.Result;
                    Console.WriteLine(courses);
                    //foreach (var student in students)
                    //{
                    //    Console.WriteLine(student.Name);
                    //}
                }
            }
            Console.ReadLine();

        }
    }
}
