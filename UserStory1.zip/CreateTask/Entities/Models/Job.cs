﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public enum Priority
    {
        High, Moderate, low
    }
    public enum Status
    {
        InProgress, Completed
    }
    public class Job
    {
        public int ID { get; set; }
        [Display(Name = "Task Name")]
        [Required]
        public string Name { get; set; }
        //public User Task_Owner { get; set; }
        //public User Creator_ID { get; set; }
        [MaxLength(100)]
        public string Description { get; set; }
        //[MaxLength(15)]

        public Status Status { get; set; }
        public Priority Priority { get; set; }
        [DataType(DataType.Date)]
        [Display(Name = "Created On")]
        [DisplayFormat(DataFormatString = "{0:dd-mm-YYYY}", ApplyFormatInEditMode = true)]
        public DateTime CreatedOn { get; set; }
        [DataType(DataType.Date)]
        [Display(Name = "Modified On")]
        [DisplayFormat(DataFormatString = "{0:dd-mm-YYYY}", ApplyFormatInEditMode = true)]
        public DateTime ModifiedOn { get; set; }

        [Display(Name = "Completion Date")]
        [DisplayFormat(DataFormatString = "{0:dd-mm-YYYY}", ApplyFormatInEditMode = true)]
        public DateTime Completion_Date { get; set; }
    }
}
