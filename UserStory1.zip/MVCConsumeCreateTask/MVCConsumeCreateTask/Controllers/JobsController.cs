﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MVCConsumeCreateTask.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace MVCConsumeCreateTask.Controllers
{
    public class JobsController : Controller
    {
        // GET: JobsController
        public async Task<ActionResult> Index()
        {
            List<Job> job = new List<Job>();
            using (var httpClient = new HttpClient())
            {
                using (var resp = await httpClient.GetAsync("https://localhost:44397/api/job"))
                {
                    string apiResponse = await resp.Content.ReadAsStringAsync();
                    job = JsonConvert.DeserializeObject<List<Job>>(apiResponse);
                }
            }
                return View(job);
        }

            // GET: JobsController/Details/5
        //    public async Task<IActionResult> Details(int id)
        //{
        //    Job j = new Job();
        //    using (var httpClient = new HttpClient())
        //    {
        //        StringContent content = new StringContent(JsonConvert.SerializeObject(j), Encoding.UTF8, "application/json");
        //        using (var response = await httpClient.PostAsync("https://localhost:44397/api/job/?id", content))
        //        {
        //            string apiResponse = await response.Content.ReadAsStringAsync();
        //            j = JsonConvert.DeserializeObject<Job>(apiResponse);
        //        }
        //    }
        //    return View();
        //}

        // GET: JobsController/Create
        public ViewResult  Post()
        {
            return View();
            
        }

        // POST: JobsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Post(Job job)
        {
            try
            {
                Job j = new Job();
                using (var httpClient = new HttpClient())
                {
                    StringContent content = new StringContent(JsonConvert.SerializeObject(job), Encoding.UTF8, "application/json");
                    using (var response = await httpClient.PostAsync("https://localhost:44397/api/job", content))
                    {
                        string apiResponse = await response.Content.ReadAsStringAsync();
                        j = JsonConvert.DeserializeObject<Job>(apiResponse);
                    }
                }
                return View(j);
            }
            catch
            {
                return View();
            }
        }

        // GET: JobsController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: JobsController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: JobsController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: JobsController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
