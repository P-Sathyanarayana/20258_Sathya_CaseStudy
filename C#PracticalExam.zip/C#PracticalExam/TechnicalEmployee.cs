﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise
{
    class TechnicalEmployee:Employee
    {
        /// <summary>
        /// Class TechnicalEmployee
        /// </summary>
        public string[] technicalSkill { get; set; }
        public float sal;
        public float HRA;

        /// <summary>
        /// Parametarized Constructor
        /// </summary>
        /// <param name="EmployeeID"></param>
        /// <param name="EmployeeName"></param>
        /// <param name="Address"></param>
        /// <param name="BasicPay"></param>
        /// <param name="TechnicalSkill"></param>
        public TechnicalEmployee(int EmployeeID, string EmployeeName, string Address, float BasicPay, string[] TechnicalSkill):base(EmployeeID, EmployeeName, Address, BasicPay)
        {
            this.technicalSkill = TechnicalSkill;
        }
        /// <summary>
        /// Abstract method overriding
        /// </summary>
        public override string calculateSalary()                 
        {
            this.HRA = (float)(12.0 / 100) * this.basePay;
            this.sal = this.basePay + this.HRA;
            return $"The salary of {this.EmpName} is Rs. {this.sal}";
        }
        /// <summary>
        /// Method overriding
        /// </summary>
        /// <returns></returns>
        public override string ToString()     
        {
            return $"Employee ID:{this.EmpID}\n" +
                $"Employee Name:{this.EmpName}";
        }
        /// <summary>
        /// Displays the employee details
        /// </summary>
        /// <returns></returns>
        public string display()
        {
            return $"{this.EmpName}'s ID is {this.EmpID}, he stays at {this.address} and gets the salary of Rs. {this.sal}";
        }
        /// <summary>
        /// Exception Handling for Employee ID
        /// </summary>
        public void ValidateEmpID()
        {
            if (this.EmpID < 0 || this.EmpID>30000)
            {
                throw (new InvalidEmpID("Employee ID is invalid"));
            }

        }
        public class InvalidEmpID : Exception
        {
            public InvalidEmpID(string message) : base(message)
            {

            }
        }
        /// <summary>
        /// Exception Handling for BasicPay
        /// </summary>
        public void ValidateBasePay()
        {
            if (this.basePay < 0 )
            {
                throw (new InvalidBasePay("Base Salary is invalid"));
            }

        }
        public class InvalidBasePay : Exception
        {
            public InvalidBasePay(string message) : base(message)
            {

            }
        }


    }
    class UsingPeople
    {
        public static void Main(string[] args)
        {
            TechnicalEmployee t= new TechnicalEmployee(20, "Abc", "Xyz", 20000,new string[] { "C", "C++", "C#" });

           
            try
            {
                t.ValidateEmpID();
                Console.WriteLine(t.ToString());
                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            try
            {
                t.ValidateBasePay();
                Console.WriteLine(t.calculateSalary());
                Console.WriteLine(t.display());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }



            Staff s = new Staff(200, "Def", "Uvw", 15000, "Security");

            try
            {
                s.ValidateEmpID();
                Console.WriteLine(s.ToString());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                
            }
            try
            {
                s.ValidateBasePay();
                Console.WriteLine(s.calculateSalary());
                Console.WriteLine(s.display());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }

        }
    }
}
