﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise
{
    class Staff:Employee
    {
        public string title;
        public float sal;
        public float HRA;
        public Staff(int EmpID, string EmpName, string address, float basePay, string Title) : base(EmpID, EmpName, address, basePay)
        {
            this.title = Title;
        }
        /// <summary>
        ///  Abstract method overriding
        /// </summary>
        /// <returns></returns>
        public override string calculateSalary()   
        {
            this.HRA = (float)(18.0 / 100) * this.basePay;
            this.sal = this.basePay + this.HRA;
            return $"The salary of {this.EmpName} is Rs. {this.sal}";
        }
        /// <summary>
        /// Method overriding
        /// </summary>
        /// <returns></returns>
        public override string ToString()                    
        {
            return $"Employee ID:{this.EmpID}\n" +
                $"Employee Name:{this.EmpName}";
        }
        /// <summary>
        /// Displays the employee details
        /// </summary>
        public string display()
        {
            return $"{this.EmpName}'s ID is {this.EmpID}, he stays at {this.address} and gets the salary of Rs. {this.sal}";
        }
        /// <summary>
        /// Exception Handling for Employee ID
        /// </summary>
        public void ValidateEmpID()
        {
            if (this.EmpID < 0 || this.EmpID > 30000)
            {
                throw (new InvalidEmpID("Employee ID is invalid"));
            }

        }
        public class InvalidEmpID : Exception
        {
            public InvalidEmpID(string message) : base(message)
            {

            }
        }
        /// <summary>
        /// Exception Handling for BasicPay
        /// </summary>
        public void ValidateBasePay()
        {
            if (this.basePay < 0)
            {
                throw (new InvalidBasePay("Base Salary is invalid"));
            }

        }
        public class InvalidBasePay : Exception
        {
            public InvalidBasePay(string message) : base(message)
            {

            }
        }
    }
}
